#!/usr/bin/env python3
"""Rebuild this drawing issue from its frozen inputs, without network or game writes."""
from pathlib import Path
import argparse, shutil, subprocess, sys, tempfile

parser=argparse.ArgumentParser();parser.add_argument('--out',required=True,type=Path);args=parser.parse_args()
package=Path(__file__).resolve().parent.parent
out=args.out.resolve()
if out.exists() and any(out.iterdir()):raise SystemExit('Output directory must be new or empty.')
with tempfile.TemporaryDirectory(prefix='minato-er-cad-')as td:
    stage=Path(td)
    (stage/'tmp').mkdir();(stage/'reference').mkdir()
    src=stage/'cache/johansson-town/src/world';src.mkdir(parents=True)
    for f in(package/'source').glob('*.js'):shutil.copy2(f,src/f.name)
    for name in['build_engine_room.py','build_headroom_h1.py']:shutil.copy2(package/'source'/name,stage/name)
    shutil.copy2(package/'data/current_main_snapshot.json',stage/'tmp/current_snapshot.json')
    shutil.copy2(package/'data/equipment_bars.json',stage/'tmp/equipment_bars.json')
    shutil.copy2(package/'references/Original_RevB_Unchanged.zip',stage/'reference/Minato_Maru_Engine_Room_CAD_Reviewed_RevB.zip')
    for name in['build_engine_room.py','build_headroom_h1.py']:subprocess.run([sys.executable,name],cwd=stage,check=True)
    shutil.copytree(stage/'output/Minato_Maru_Engine_Room_RevC',out,dirs_exist_ok=True)
print(out)
