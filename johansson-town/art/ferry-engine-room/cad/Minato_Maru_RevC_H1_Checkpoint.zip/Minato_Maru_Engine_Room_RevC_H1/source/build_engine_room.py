#!/usr/bin/env python3
"""Minato Maru ER Rev C: source survey, CAD and realism review. No game writes."""
from pathlib import Path
import json, math, csv, hashlib, shutil, zipfile, collections, re
import numpy as np
import ezdxf
from ezdxf.enums import TextEntityAlignment
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor
from reportlab.pdfbase.pdfmetrics import stringWidth
from PIL import Image
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'output/Minato_Maru_Engine_Room_RevC'
for folder in ['drawings','cad','data','source','references','previews']: (OUT/folder).mkdir(parents=True,exist_ok=True)
S=json.loads((ROOT/'tmp/current_snapshot.json').read_text())
I=S['interior']; COMMIT='f49f22ba82e6d4b1fd9b5033f8bddc4d3eed903f'
MM=72/25.4; W=594; H=420
INK='#203b45'; TEAL='#246a68'; LIGHT='#e7efec'; RED='#ae4b3e'; GOLD='#b28b38'; GRAY='#75848a'
DATE='31 October 2026'
REG=[]

def point(p): return np.array([(p[2]+17.25)*1000,p[0]*1000,(p[1]+1.9)*1000])
def colour(n): return '#%06x'%n if isinstance(n,int) else n
def clean(s):
    for a,b in {'\u00d7':' x ','\u2013':'-','\u2014':'-','\u2019':"'",'\u2082':'2','\u00b3':'3','\u00b2':'2','\u2192':' > ','\u00b0':' deg'}.items(): s=str(s).replace(a,b)
    return s.encode('latin-1','replace').decode('latin-1')
def csvout(path,rows):
    if not rows:return
    with open(path,'w',newline='')as f:
        keys=list(dict.fromkeys(k for r in rows for k in r))
        c=csv.DictWriter(f,fieldnames=keys);c.writeheader();c.writerows(rows)

BOX=[]
for k,b in enumerate(I['boxes']):
    a,c=point(b['a']),point(b['b']);lo=np.minimum(a,c);hi=np.maximum(a,c)
    if hi[0]>=6900 and lo[0]<=26060 and lo[2]<3000 and hi[2]>=840:
        BOX.append(dict(b,lo=lo,hi=hi,index=k))

def rotation(rot):
    x,y,z=rot;cx,sx,cy,sy,cz,sz=math.cos(x),math.sin(x),math.cos(y),math.sin(y),math.cos(z),math.sin(z)
    return np.array([[cy,0,sy],[0,1,0],[-sy,0,cy]])@np.array([[1,0,0],[0,cx,-sx],[0,sx,cx]])@np.array([[cz,-sz,0],[sz,cz,0],[0,0,1]])
def cylinder(c,n=12):
    ang=np.arange(n)*2*math.pi/n
    v=np.array([[r*math.cos(t),y,r*math.sin(t)]for y,r in [(-c['h']/2,c['rb']),(c['h']/2,c['rt'])]for t in ang])
    v=v@rotation(c.get('rot',[0,0,0])).T+np.array(c['pos'])
    return np.array([point(p)for p in v])
CYL=[]
for k,c in enumerate(I['cyls']):
    if c.get('name') in ['pipe bend','penetration']:continue
    v=cylinder(c);lo=v.min(axis=0);hi=v.max(axis=0)
    if hi[0]>=6900 and lo[0]<=26060 and lo[2]<3000 and hi[2]>=840:
        CYL.append(dict(c,vertices=v,lo=lo,hi=hi,index=k))

def rectfaces(lo,hi):
    a,b,c=lo;d,e,f=hi
    v=np.array([[a,b,c],[d,b,c],[d,e,c],[a,e,c],[a,b,f],[d,b,f],[d,e,f],[a,e,f]])
    return v,[[0,1,2,3],[4,7,6,5],[0,4,5,1],[1,5,6,2],[2,6,7,3],[3,7,4,0]]

def make_cutaway():
    fig=plt.figure(figsize=(15,11),dpi=180,facecolor='#f8f7f2');ax=fig.add_subplot(111,projection='3d');ax.set_facecolor('#f8f7f2')
    polygons=[];colors=[];meshes=[]
    # Existing continuous working floor; clip its presentation to the ER/aux cutaway.
    floor_v,floor_f=rectfaces(np.array([8500.,-3980.,840.]),np.array([19000.,3980.,900.]))
    meshes.append(('working floor - clipped presentation',floor_v,floor_f,'#b7c7bb'))
    for face in floor_f:polygons.append(floor_v[face]/1000);colors.append('#b7c7bb')
    for b in BOX:
        lo=b['lo'].copy();hi=b['hi'].copy();name=b.get('name')or''
        if lo[0]<8450 or hi[0]>19050 or b.get('draw') is False:continue
        if 'deckhead' in name or 'bulkhead' in name or 'side' in name or 'trunk' in name or 'floor plates' in name:continue
        if hi[2]>2800 or hi[2]<850:continue
        if np.any(hi-lo<1):continue
        v,f=rectfaces(lo,hi);col=colour(b['hex']);meshes.append((name or 'source box',v,f,col))
        for face in f:polygons.append(v[face]/1000);colors.append(col)
    for c in CYL:
        if c['lo'][0]<8450 or c['hi'][0]>19050 or c['hi'][2]>2800:continue
        if c.get('name') in ['strainer stud','door bolt','bulkhead lamp']:continue
        v=c['vertices'];n=len(v)//2;f=[list(range(n-1,-1,-1)),list(range(n,2*n))]+[[k,(k+1)%n,(k+1)%n+n,k+n]for k in range(n)]
        col=colour(c['hex']);meshes.append((c.get('name')or 'source cylinder',v,f,col))
        for face in f:polygons.append(v[face]/1000);colors.append(col)
    # Exact retained non-preview bars, verified by the Node extractor.
    bars=json.loads((ROOT/'tmp/equipment_bars.json').read_text())
    for bar in bars:
        a,b=point(bar['a']),point(bar['b'])
        if min(a[0],b[0])<8450 or max(a[0],b[0])>19050 or max(a[2],b[2])>2800 or min(a[2],b[2])<840:continue
        ax.plot(*np.stack([a,b]).T/1000,color=colour(bar['hex']),lw=max(.5,bar['r']*22),alpha=1)
    pc=Poly3DCollection(polygons,facecolors=colors,edgecolors='#48615a',linewidths=.15,zsort='average',shade=False)
    ax.add_collection3d(pc)
    for x in [8.5,14,19]:ax.plot([x,x],[-3.98,3.98],[.9,.9],color=INK,lw=1.2)
    for y in [-3.98,3.98]:ax.plot([8.5,19],[y,y],[.9,.9],color=INK,lw=1)
    ax.text(11.1,4.15,.88,'MAIN ENGINE ROOM',fontsize=9,color=INK,ha='center')
    ax.text(16.55,4.15,.88,'AUXILIARY MACHINERY',fontsize=9,color=INK,ha='center')
    ax.set_xlim(8.2,19.3);ax.set_ylim(-4.4,4.4);ax.set_zlim(.65,3.1);ax.set_box_aspect((11.1,8.8,2.45));ax.set_proj_type('ortho');ax.view_init(elev=48,azim=-53);ax.set_axis_off()
    fig.subplots_adjust(left=0,right=1,bottom=0,top=1)
    fig.savefig(OUT/'previews/Minato_Maru_Engine_Room_Cutaway.png',dpi=180,facecolor=fig.get_facecolor(),bbox_inches='tight',pad_inches=.1)
    plt.close(fig)
    # Source-coordinate polygon mesh, mm. Surfaces are the current game, not a selected-maker model.
    f=(OUT/'cad/Minato_Maru_Machinery_Source.obj').open('w');f.write('# CAD mm: X forward from transom; Y port; Z above baseline.\nmtllib Minato_Maru_Machinery_Source.mtl\n');idx=1;materials={}
    d=ezdxf.new('R2010');d.units=4;ms=d.modelspace()
    for no,(name,v,faces,col)in enumerate(meshes):
        mat='m'+col[1:];materials[mat]=col
        f.write('o '+re.sub('[^a-zA-Z0-9_]','_',name)+'_'+str(no)+'\nusemtl '+mat+'\n')
        for p in v:f.write('v '+' '.join(f'{x:.4f}'for x in p)+'\n')
        for face in faces:
            f.write('f '+' '.join(str(idx+k)for k in face)+'\n')
            vs=[tuple(v[k])for k in face]
            if len(vs)>4:
                for j in range(1,len(vs)-1):ms.add_3dface([vs[0],vs[j],vs[j+1],vs[j+1]])
            else:ms.add_3dface(vs if len(vs)==4 else vs+[vs[-1]])
        idx+=len(v)
    f.close()
    with open(OUT/'cad/Minato_Maru_Machinery_Source.mtl','w')as f:
        for name,col in materials.items():f.write('newmtl '+name+'\nKd '+' '.join(f'{int(col[k:k+2],16)/255:.4f}'for k in [1,3,5])+'\n\n')
    d.saveas(OUT/'cad/Minato_Maru_Machinery_Source_3D.dxf')
    return len(meshes)

class Book:
    def __init__(self,total=10,filename='Minato_Maru_Engine_Room_RevC.pdf',proposal=False):
        self.total=total;self.proposal=proposal
        self.c=canvas.Canvas(str(OUT/filename),pagesize=(W*MM,H*MM),pageCompression=1)
        self.c.setTitle('Minato Maru - engine room CAD and realism review - Rev C')
        self.c.setAuthor('Johansson World - engineering arrangement study')
        self.n=0;self.ops=[];self.textbounds=[];self.pages=[]
    def text(self,x,y,t,size=2.8,bold=False,col=INK,align='left'):
        t=clean(t);font='Helvetica-Bold'if bold else'Helvetica';self.c.setFont(font,size*MM);self.c.setFillColor(HexColor(col))
        fn={'left':self.c.drawString,'center':self.c.drawCentredString,'right':self.c.drawRightString}[align];fn(x*MM,y*MM,t)
        tw=stringWidth(t,font,size*MM)/MM;xx=x if align=='left'else x-tw if align=='right'else x-tw/2
        self.textbounds.append([self.n,xx,y,xx+tw,y+size,t]);self.ops.append(('text',x,y,t,size,bold,col,align))
    def line(self,a,b,col=INK,w=.25,dash=None):
        self.c.setStrokeColor(HexColor(col));self.c.setLineWidth(w*MM);self.c.setDash(dash or[]);self.c.line(a[0]*MM,a[1]*MM,b[0]*MM,b[1]*MM);self.c.setDash([]);self.ops.append(('line',a,b,col,w,dash))
    def rect(self,x,y,w,h,col=INK,fill=None,lw=.25,dash=None):
        self.c.setStrokeColor(HexColor(col));self.c.setLineWidth(lw*MM);self.c.setDash(dash or[])
        if fill:self.c.setFillColor(HexColor(fill))
        self.c.rect(x*MM,y*MM,w*MM,h*MM,stroke=1,fill=bool(fill));self.c.setDash([]);self.ops.append(('rect',x,y,w,h,col,fill,lw,dash))
    def poly(self,p,col=INK,fill=None,w=.25):
        q=self.c.beginPath();q.moveTo(*[v*MM for v in p[0]])
        for a in p[1:]:q.lineTo(*[v*MM for v in a])
        q.close();self.c.setLineWidth(w*MM);self.c.setStrokeColor(HexColor(col))
        if fill:self.c.setFillColor(HexColor(fill))
        self.c.drawPath(q,stroke=1,fill=bool(fill));self.ops.append(('poly',p,col,fill,w))
    def circle(self,x,y,r,col=INK,fill=None):
        self.c.setStrokeColor(HexColor(col));self.c.setLineWidth(.22*MM)
        if fill:self.c.setFillColor(HexColor(fill))
        self.c.circle(x*MM,y*MM,r*MM,stroke=1,fill=bool(fill));self.ops.append(('circle',x,y,r,col,fill))
    def wrap(self,x,y,t,w,size=2.8,leading=4.8,bold=False,col=INK):
        for para in t.split('\n'):
            line=''
            for word in para.split():
                test=(line+' '+word).strip()
                if stringWidth(clean(test),'Helvetica-Bold'if bold else'Helvetica',size*MM)/MM>w:
                    self.text(x,y,line,size,bold,col);y-=leading;line=word
                else:line=test
            if line:self.text(x,y,line,size,bold,col);y-=leading
        return y
    def note(self,x,y,number,title,body,w=220):
        self.text(x,y,number+'  '+title,3.2,True,TEAL);return self.wrap(x,y-6,body,w,2.8,4.9)-7
    def sheet(self,code,title,scale='NTS'):
        if self.n:self.endpage()
        self.n+=1;self.code=code;self.ops=[];self.pages.append(dict(page=self.n,code=code,title=title,scale=scale))
        self.rect(10,10,574,400,lw=.5);self.line((10,381),(584,381),TEAL,.5);self.line((10,47),(584,47),TEAL,.4)
        self.text(20,398,'JOHANSSON WORLD / MINATO MARU',4.6,True,TEAL);self.text(20,387,title,4,True)
        self.text(574,398,code,4,True,align='right');self.text(574,387,'REV C  |  '+scale,3,align='right')
        self.text(20,35,'HEADROOM H1 / PROPOSED DIMENSIONS' if self.proposal else 'CURRENT MODEL SURVEY + ENGINEERING REVIEW',3.3,True)
        self.text(20,27,'Dimensioned from main '+COMMIT[:12]+'  |  '+DATE+'  |  Units mm; dimensions govern.',2.7)
        self.text(20,19,'FOR LAYOUT REVIEW. GAME UNCHANGED. OPEN ENGINEERING ITEMS ARE SHOWN; NO FABRICATION RELEASE.',2.6,True,RED)
        self.text(574,28,f'SHEET {self.n:02d} / {self.total:02d}',3.3,True,align='right');self.text(574,19,'Drawn: source-derived  |  Checked: computational / visual  |  Approval: none',2.25,align='right')
    def endpage(self):
        self.write_svg();self.c.showPage()
    def write_svg(self):
        import html
        a=[f'<svg xmlns="http://www.w3.org/2000/svg" width="594mm" height="420mm" viewBox="0 0 594 420">','<rect width="594" height="420" fill="white"/>']
        for o in self.ops:
            if o[0]=='text':
                _,x,y,t,sz,b,col,al=o;a.append(f'<text x="{x}" y="{H-y}" font-size="{sz}" font-family="Arial,sans-serif" font-weight="{700 if b else 400}" fill="{col}" text-anchor="'+{'left':'start','right':'end','center':'middle'}[al]+'">'+html.escape(t)+'</text>')
            elif o[0]=='line':
                _,p,q,col,lw,dash=o;a.append(f'<path d="M {p[0]} {H-p[1]} L {q[0]} {H-q[1]}" fill="none" stroke="{col}" stroke-width="{lw}"'+(f' stroke-dasharray="{",".join(map(str,dash))}"'if dash else'')+'/>')
            elif o[0]=='rect':
                _,x,y,w,h,col,fill,lw,dash=o;a.append(f'<rect x="{x}" y="{H-y-h}" width="{w}" height="{h}" stroke="{col}" fill="{fill or "none"}" stroke-width="{lw}"'+(f' stroke-dasharray="{",".join(map(str,dash))}"'if dash else'')+'/>')
            elif o[0]=='poly':
                _,p,col,fill,lw=o;a.append('<polygon points="'+' '.join(f'{x},{H-y}'for x,y in p)+f'" stroke="{col}" fill="{fill or "none"}" stroke-width="{lw}"/>')
            elif o[0]=='circle':
                _,x,y,r,col,fill=o;a.append(f'<circle cx="{x}" cy="{H-y}" r="{r}" stroke="{col}" fill="{fill or "none"}" stroke-width="0.22"/>')
            elif o[0]=='image':
                import base64
                _,path,x,y,w,h=o
                data=base64.b64encode(Path(path).read_bytes()).decode()
                a.append(f'<image x="{x}" y="{H-y-h}" width="{w}" height="{h}" preserveAspectRatio="xMidYMid meet" href="data:image/png;base64,{data}"/>')
        a.append('</svg>');(OUT/'drawings'/f'{self.code}.svg').write_text('\n'.join(a))
    def dimh(self,p1,p2,y,t):
        for p in [p1,p2]:self.line(p,(p[0],y+2),GRAY,.15)
        self.line((p1[0],y),(p2[0],y),GRAY,.18)
        for x in[p1[0],p2[0]]:self.line((x-1.1,y-1.1),(x+1.1,y+1.1),GRAY,.25)
        self.text((p1[0]+p2[0])/2,y+1.9,t,2.7,align='center')
    def dimv(self,p1,p2,x,t):
        for p in [p1,p2]:self.line(p,(x+2,p[1]),GRAY,.15)
        self.line((x,p1[1]),(x,p2[1]),GRAY,.18)
        for y in[p1[1],p2[1]]:self.line((x-1.1,y-1.1),(x+1.1,y+1.1),GRAY,.25)
        self.text(x+2,(p1[1]+p2[1])/2,t,2.7)
    def balloon(self,pos,label,colour_=TEAL):
        self.circle(*pos,3.6,colour_,'#ffffff');self.text(pos[0],pos[1]-1,label,2.8,True,colour_,align='center')
    def finish(self):
        self.endpage();self.c.save();(OUT/'data/drawing_register.json').write_text(json.dumps(self.pages,indent=2));(OUT/'data/text_bounds.json').write_text(json.dumps(self.textbounds))

B=Book()
def plan(x0,x1,origin,scale,detail=True,markers=None):
    ox,oy=origin
    def p(x,y):return(ox+(x-x0)/scale,oy+(y+3980)/scale)
    B.rect(*p(x0,-3980),(x1-x0)/scale,7960/scale,INK,'#f5f7f4',.45)
    # floorplate seams; no fictitious second platform.
    for x in np.arange(math.ceil(x0/500)*500,x1+1,500):
        B.line(p(x,-3980),p(x,3980),'#dbe3e0',.12)
    items=sorted([b for b in BOX if b['lo'][0]>=x0-60 and b['hi'][0]<=x1+60 and b['hi'][2]<=2801 and b.get('draw') is not False and not any(a in(b.get('name')or'')for a in['deckhead','floor plates','room side','space side'])],key=lambda b:b['hi'][2])
    for b in items:
        lo,hi=b['lo'],b['hi'];xx=max(x0,lo[0]);xe=min(x1,hi[0]);yy=max(-3980,lo[1]);ye=min(3980,hi[1]);
        if xe<=xx or ye<=yy:continue
        col=colour(b['hex']);fill=col if b['hi'][2]>1050 else '#dae1dd'
        B.rect(*p(xx,yy),(xe-xx)/scale,(ye-yy)/scale,INK,fill,.18)
    if detail:
        for c in sorted(CYL,key=lambda c:c['hi'][2]):
            lo,hi=c['lo'],c['hi']
            if lo[0]<x0 or hi[0]>x1 or hi[2]>2800 or lo[1]<-3980 or hi[1]>3980:continue
            # exact cylinder projected convex hull
            from scipy.spatial import ConvexHull
            pts=c['vertices'][:,[0,1]]
            try:pts=pts[ConvexHull(pts).vertices]
            except Exception:continue
            B.poly([p(*v)for v in pts],INK,colour(c['hex']),.14)
    # handrail footprint is a clearance constraint even when renderer uses bars.
    if x0<=9280 and x1>=12420:
        for sign in [-1,1]:
            a,b=sorted([sign*650,sign*2450]);B.rect(*p(9300,a),3100/scale,(b-a)/scale,GOLD,None,.55)
    B.line(p(x0,0),p(x1,0),GRAY,.18,[3,1,1,1])
    B.text(*p(x1-120,-280), 'CL',2.6,col=GRAY,align='right')
    B.dimh(p(x0,3980),p(x1,3980),oy+7960/scale+9,f'{x1-x0:,.0f}')
    B.dimv(p(x0,-3980),p(x0,3980),ox-11,'7,960')
    B.text(ox+2,oy+3,'AFT',2.8,True);B.text(ox+(x1-x0)/scale-2,oy+3,'FORWARD >',2.8,True,align='right')
    B.text(ox,oy+7960/scale+3,'PORT',2.8,True)
    if markers:
        for x,y,label in markers:B.balloon(p(x,y),label)
    return p

def section(x0,x1,origin,scale,ycut,title):
    ox,oy=origin
    def p(x,z):return(ox+(x-x0)/scale,oy+(z-700)/scale)
    B.text(ox,oy+59,title,3.4,True,TEAL)
    B.rect(*p(x0,840),(x1-x0)/scale,60/scale,GRAY,'#abb7b4')
    B.rect(*p(x0,2800),(x1-x0)/scale,180/scale,GRAY,'#c2cac7')
    for b in sorted(BOX,key=lambda b:b['hi'][2]):
        lo,hi=b['lo'],b['hi']
        if b.get('draw')is False or lo[0]<x0 or hi[0]>x1 or hi[2]>2800 or hi[2]<900:continue
        if lo[1]<=ycut<=hi[1] and not any(w in(b.get('name')or'')for w in['side','deckhead','floor plates']):B.rect(*p(lo[0],lo[2]),(hi[0]-lo[0])/scale,(hi[2]-lo[2])/scale,INK,colour(b['hex']),.18)
    for c in CYL:
        lo,hi=c['lo'],c['hi']
        if lo[0]<x0 or hi[0]>x1 or hi[2]>2800 or not(lo[1]-30<=ycut<=hi[1]+30):continue
        from scipy.spatial import ConvexHull
        vs=c['vertices'][:,[0,2]]
        try:vs=vs[ConvexHull(vs).vertices]
        except Exception:continue
        B.poly([p(*v)for v in vs],INK,colour(c['hex']),.14)
    B.line(p(x0,700),p(x1,700),RED,.22,[2,1]);B.text(*p(x1,700),'TANK TOP +700',2.5,col=RED,align='right')
    B.dimv(p(x1,900),p(x1,2800),ox+(x1-x0)/scale+7,'1,900')
    return p

mesh_count=make_cutaway()
# 01 - immediate, source-derived picture and scope.
B.sheet('JS127-ER-C01','Machinery arrangement / source-derived cutaway','NTS / plan 1:100')
B.c.drawImage(str(OUT/'previews/Minato_Maru_Engine_Room_Cutaway.png'),16*MM,170*MM,350*MM,199*MM,preserveAspectRatio=True,anchor='c',mask='auto')
B.ops.append(('image',str(OUT/'previews/Minato_Maru_Engine_Room_Cutaway.png'),16,170,350,199))
B.text(24,166,'DECKHEADS AND EXTERNAL WALLS OMITTED FOR VISIBILITY ONLY',2.5,True,GRAY)
y=366
y=B.note(385,y,'01','Existing ferry retained','34,500 LOA x 8,400 moulded breadth. Twin-screw, bow-ramp island ferry. This issue draws current machinery; no equipment is added, deleted or relocated.',183)
y=B.note(385,y,'02','Propulsion retained','Two fictional Johansson Marine JM6-160 six-cylinder diesels: 460 kW at 1,350 rpm each; reverse-reduction gears aft, 3:1. Engines point forward; shafts leave aft.',183)
y=B.note(385,y,'03','Power and auxiliaries','Two 100 kW diesel-generator sets in the auxiliary room. Fire/GS, bilge, fuel transfer, purifier, air receivers, compressors and domestic systems remain in place.',183)
y=B.note(385,y,'04','What realism requires','Preserve correct scale, connected services, access to every maintainable part, protected exits and a practical lifting route. Simplify mesh detail only after these physical relationships work.',183)
B.text(24,151,'Machinery-space chain / principal dimensions',3.6,True,TEAL)
p=plan(8500,26000,(25,62),100,False)
for x,label in [(8500,'ER'),(14000,'AUX'),(19000,'MECH / STORE'),(22500,'ELECTRICAL')]:
    if x>8500:B.line(p(x,-3980),p(x,3980),TEAL,.45)
    B.text(*p(x+180,3300),label,2.8,True,TEAL)
# source plan thumbnail overlaps image? thumbnail drawn as controlled narrow strip below.

# 02 - full engine room plan.
B.sheet('JS127-ER-C02','Main engine room / equipment and working clearances','1:25 @ A2')
marks=[(10850,1550,'1'),(10850,-1550,'2'),(8760,2500,'3'),(9150,2900,'4'),(10600,3800,'5'),(12000,3700,'6'),(12980,3700,'7'),(8800,-3200,'8'),(10000,-3500,'9'),(11900,-3700,'10'),(13350,-3600,'11'),(13600,3500,'12')]
p=plan(8500,14000,(44,50),25,True,marks)
B.dimh(p(9300,650),p(12400,650),p(0,650)[1]+8,'3,100 rail length')
B.dimv(p(11000,-630),p(11000,630),p(11000,0)[0]+7,'1,260 clear')
y=365
for num,title,body in [
('1/2','Main engines P / S','Current bedplates X=9,000-12,000; centres Y=+/-1,550. Actual fittings are projected from source; manufacturer installation dimensions remain unverified.'),
('3/4','Starting-air equipment','Two 150 L receivers and compressor No.1 aft to port. Receiver reliefs, drains, certified start capacity and complete piping still need detail.'),
('5-7','Port service bench / treatment','Workbench, fuel purifier and oily-water separator. Keep machinery opening and filter/basket withdrawal space; the picture alone does not prove service access.'),
('8/9','Main switchboard / control booth','MSB aft, engine console and log desk along the side. Current booth has one modelled doorway; protected independent escape is unresolved.'),
('10','Starboard pump row','Fire / GS No.1; fire / bilge No.2; GS; bilge; sanitary No.1; hydrophore No.1. Sequence and installed count retained.'),
('11/12','Fuel service tank / sea-water strainer','Service tank remains forward starboard. Both sea-water suctions/strainers must remain accessible. Tank, hot exhaust and switchboard routes must be coordinated.'),
]:y=B.note(309,y,num,title,body,258)
B.wrap(309,89,'Closed yellow rail loops currently surround both engines. No gate is modelled; a maintainable machine cannot rely on climbing a rail. A correction must retain guarded edges and provide deliberate service access.',258,2.9,5,col=RED)

# 03 - auxiliaries.
B.sheet('JS127-ER-C03','Auxiliary machinery room / generators and service plant','1:25 @ A2')
marks=[(15550,1500,'1'),(15550,-1500,'2'),(14150,3750,'3'),(15100,3750,'4'),(15900,3750,'5'),(17800,3200,'6'),(15500,-3700,'7'),(16900,-3700,'8'),(14250,-3770,'9'),(17600,-3650,'10'),(18500,-3650,'11')]
p=plan(14000,19000,(44,50),25,True,marks)
B.dimv(p(15550,-550),p(15550,550),p(15550,0)[0]+7,'1,100 beds')
y=365
for num,title,body in [
('1/2','Diesel generators No.1 / No.2','Current set beds X=15,200-16,050, Y=550-2,400 and -2,400 to -550. Inboard dynamic fittings leave a smaller declared 1,000 mm working aisle.'),
('3','Fuel transfer No.1 / No.2','Two separate pumps remain. Dedicated suction/discharge interfaces and control/bypass arrangements need the unpublished fuel C1 design to be reviewed.'),
('4/5','Domestic standby / sewage pumps','Hydrophore No.2, sanitary No.2 and sewage discharge No.2. Sewage discharge No.1 is between the pump row and holding tank.'),
('6','Sewage holding tank','Nominal 4 m3, current external envelope 1,600 x 1,600 x 1,700. Gross envelope is 4.352 m3, before platework, internals and unusable volume.'),
('7-10','Starboard services','Ballast manifold, ballast pump, compressor No.2 and 300 L hydrophore vessel. Access to valve spindles, motor withdrawals and pressure-vessel inspections remains a hold.'),
('11','Forward starboard escape','A 700 mm-wide model trunk is drawn. It is an existing representation, not a proved protected exit to a safe deck. Route and fire-boundary details must be completed.'),
]:y=B.note(302,y,num,title,body,265)
B.wrap(302,91,'Door at X=14,000: 800 mm nominal wide. Door at X=19,000: 750 mm nominal wide. Do not route machinery removal through these openings unless the dismantled item and rigging fit.',265,2.9,5,col=RED)

# 04 - workshop spaces, including the later Tetsuo room.
B.sheet('JS127-ER-C04','Mechanical workshop, engine store and electrical workshop','1:40 @ A2')
p=plan(19000,26000,(37,135),40,True,[(20500,3550,'1'),(19800,2500,'2'),(22200,2600,'3'),(21100,-3750,'4'),(22100,-1800,'5'),(25600,1800,'6'),(24500,-3400,'7'),(24900,-3650,'8')])
B.line(p(22500,-3980),p(22500,3980),TEAL,.5)
B.text(*p(21000,4300),'MECHANICAL / STORE',3.1,True,TEAL,align='center');B.text(*p(24300,4300),'ELECTRICAL WORKSHOP',3.1,True,TEAL,align='center')
B.dimh(p(19000,-3980),p(22500,-3980),114,'3,500');B.dimh(p(22500,-3980),p(26000,-3980),114,'3,500')
y=363
for num,title,body in [('1-3','Mechanical work','Lathe, pedestal drill, main bench and vice remain. Welding set and grinder remain in the room; hot-work control, screens and extraction are not established by the model.'),('4/5','Engine store','Spares racks, two oil drums and chain block remain. Mesh partition retained. A stored chain block is not a designed lifting beam or a complete engine-removal scheme.'),('6/7','Electrical work','The later electrical workshop is included, unlike the 13 October Rev B source snapshot: instrument bench, test panel, insulated mat and motor service area.'),('8','Electrical escape','Existing trunk at X=24,600-25,200 remains. Its through-deck continuation and hatch still need detailing. Do not treat the store as a protected safe escape location.')]:y=B.note(277,y,num,title,body,288)
B.wrap(37,92,'Current plan only. No machinery, furnishings or compartment boundaries moved. Workshop/store subdivision is the game source; its real damage-stability and fire-division basis is unresolved.',520,3.0,5)

# 05 - sections.
B.sheet('JS127-ER-C05','Longitudinal sections / levels, machinery and deck structure','1:50 @ A2')
p=section(8500,26000,(30,278),50,1550,'A-A / port machinery centre plane, Y=+1,550')
for x in [14000,19000,22500]:B.line(p(x,900),p(x,2800),GRAY,.3)
for x,label in [(8500,'ENGINE ROOM'),(14000,'AUXILIARY'),(19000,'MECH / STORE'),(22500,'ELECTRICAL')]:B.text(*p(x+170,3050),label,2.8,True)
q=section(8500,26000,(30,175),50,-1550,'B-B / starboard machinery centre plane, Y=-1,550')
for x in [14000,19000,22500]:B.line(q(x,900),q(x,2800),GRAY,.3)
B.dimh(q(8500,900),q(26000,900),161,'17,500 total machinery-space chain')
B.text(417,359,'Vertical geometry governs',3.8,True,TEAL)
y=348
for n,t,b in [('01','Floor / tank top','Tank top +700; floor plates +900; deckhead +2,800; car deck +3,000. Nominal headroom 1,900 before cable trays, pipes, stiffeners and insulation.'),('02','No imaginary extra storey','The source grating sits at about +906, on the working-floor level. The 200 mm tank-top interval is service depth, not a walkable lower machinery deck.'),('03','Overhaul above each engine','The M1 reference reservation rises to +2,550, leaving 250 mm to the deckhead. Piston/liner withdrawal and chain-block hook height are unknown.'),('04','Structural space','Deck beams, tank-top girders, foundation bolts, resilient mounts and lifting points are not fully engineered. The 180 mm model deckhead is an envelope, not an approved beam design.')]:y=B.note(417,y,n,t,b,150)
B.wrap(30,119,'Double-bottom liquid volumes are existing allocations only: two 7.5 m3 fuel-storage tanks; bilge 1.0 m3; sludge 0.3 m3; lube oil 0.6 m3. No individual tank partitions, calibrated capacities or fabrication scantlings are invented here.',348,2.9,5)
B.wrap(30,87,'The source hull and loading assumptions remain unreconciled. Do not lower the machinery floor, deepen tanks or move bulkheads to manufacture clearance without rechecking hull shape, structure, weights and stability.',528,3.1,5,col=RED)

# 06 - transverse sections.
B.sheet('JS127-ER-C06','Transverse sections / human and maintenance envelopes','1:25 @ A2')
def transverse(X,origin,title):
    ox,oy=origin
    def p(y,z):return(ox+(y+3980)/25,oy+(z-700)/25)
    B.text(ox,oy+106,title,3.4,True,TEAL);B.rect(*p(-3980,840),7960/25,60/25,GRAY,'#c3cdca');B.rect(*p(-3980,2800),7960/25,180/25,GRAY,'#c3cdca')
    for b in BOX:
        lo,hi=b['lo'],b['hi']
        if not(lo[0]<=X<=hi[0]) or hi[2]>2800 or b.get('draw')is False or hi[2]<900:continue
        B.rect(*p(lo[1],lo[2]),(hi[1]-lo[1])/25,(hi[2]-lo[2])/25,INK,colour(b['hex']),.18)
    B.line(p(0,700),p(0,3100),GRAY,.2,[3,1,1,1]);B.dimv(p(3980,900),p(3980,2800),ox+328,'1,900')
    return p
p=transverse(10700,(35,245),'C-C / engine midlength X=10,700; starboard left, port right')
for cy in [-1550,1550]:B.rect(*p(cy-750,900),1500/25,1650/25,RED,None,.45,[2,1])
B.dimh(p(-1550,2550),p(1550,2550),351,'3,100 engine-centre spacing')
B.dimv(p(2800,2550),p(2800,2800),p(2800,2550)[0]+8,'250 overhead')
q=transverse(15600,(35,102),'D-D / generator station X=15,600')
B.dimh(q(-550,900),q(550,900),86,'1,100 between beds')
y=366
for n,t,b in [('01','Measured versus reserved','Solid colour is the current game model. Red dashed boxes are retained M1 engine/gear reservations: 2,700 x 1,500 x 1,650, not manufacturer installation data.'),('02','Watchkeeper route','A 2,000 mm clear route-height target cannot fit inside the existing 1,900 mm nominal room. Actual piping/trays reduce this further. Do not hide the conflict with a smaller avatar.'),('03','Aisles','Centre aisle is 1,260 mm between actual rail faces. Side access must be checked against fittings, control-booth glazing, valve swing and required part withdrawal, not just a body capsule.'),('04','Working positions','Model a standing operator, kneeling filter service, removal of a rocker cover and the largest planned spare. Keep those envelopes clear before adding decorative props.')]:y=B.note(410,y,n,t,b,158)

# 07 - engine.
B.sheet('JS127-ER-C07','Main engine / recognisable machinery and controlled interfaces','1:10 @ A2')
def engine_elevation(origin,side=1):
    ox,oy=origin
    def p(x,z):return(ox+(x-8900)/10,oy+(z-900)/10)
    for b in sorted(BOX,key=lambda b:abs((b['lo'][1]+b['hi'][1])/2-1550),reverse=True):
        lo,hi=b['lo'],b['hi']
        if lo[0]<8950 or hi[0]>12450 or lo[1]<650 or hi[1]>2450 or b.get('draw')is False:continue
        B.rect(*p(lo[0],lo[2]),(hi[0]-lo[0])/10,(hi[2]-lo[2])/10,INK,colour(b['hex']),.2)
    for c in CYL:
        lo,hi=c['lo'],c['hi']
        if lo[0]<8950 or hi[0]>12450 or lo[1]<650 or hi[1]>2450:continue
        from scipy.spatial import ConvexHull
        v=c['vertices'][:,[0,2]]
        try:v=v[ConvexHull(v).vertices]
        except Exception:continue
        B.poly([p(*v0)for v0 in v],INK,colour(c['hex']),.16)
    B.dimh(p(9000,900),p(12000,900),oy-12,'3,000 current bedplate envelope')
    B.text(ox,oy-23,'AFT / GEARBOX + SHAFT <',2.9,True);B.text(ox+350,oy-23,'FORWARD / TURBO >',2.9,True,align='right');return p
p=engine_elevation((30,183))
B.text(30,361,'Port engine / source elevation; external details only',3.6,True,TEAL)
for x,z,n in [(9170,1500,'1'),(10700,1800,'2'),(10800,2360,'3'),(12150,2150,'4'),(12150,1600,'5')]:B.balloon(p(x,z),n)
y=366
for n,t,b in [('1','Reverse-reduction gearbox','Gear aft, flywheel/coupling between block and gear; propeller shaft leaves aft. Confirm output height, thrust reaction and coupling guard from selected equipment.'),('2/3','Six-cylinder mechanical diesel','Six rocker covers, crankcase service doors, injection equipment and lagged exhaust must read as one coherent machine. A permanently open crankcase cover is inappropriate for the running state.'),('4/5','Turbocharger and cooling','Turbocharger forward, charge-air cooler and engine-mounted pumps; starting-air, fuel feed/return, LO and cooling connections must each have a separate functional interface.')]:y=B.note(410,y,n,t,b,158)
B.text(30,124,'Real machinery comparison / not an engine substitution',3.5,True,TEAL)
B.wrap(30,114,'The retained JM6-160 is fictional: 460 kW / 1,350 rpm / 160 x 200 mm / six cylinders / 24.127 L. A verified Yanmar 6AYM-WST reference is 485 kW at 1,900 rpm, 155 x 180 mm and 20.379 L. The legacy outline is 2,000 x 1,305 x 1,431 mm engine-only; a YX181 package has 2,364 mm combined length. Do not mix those ratings, masses, starting systems or installation dimensions.',538,3,5)
B.wrap(30,77,'Drawing decision: retain installed count, purpose and shaft orientation. Obtain a period-credible matched engine/gear installation basis before replacing the fictional envelope with a detailed production asset.',538,3,5,col=RED)

# 08 - egress and lifting.
B.sheet('JS127-ER-C08','Personnel escape, component removal and engine-lift review','1:50 plan / ladder 1:30')
p=plan(6900,19000,(33,174),50,False)
for x in [8500,14000]:B.line(p(x,-3980),p(x,3980),TEAL,.4)
for x,y,t in [(7800,3550,'P ladder'),(8650,-3650,'S ladder'),(18500,-3620,'Aux escape')]:
    px,py=p(x,y);B.balloon((px,py),'E',RED);B.text(px,py+6,t,2.8,True,RED,align='center')
for cy in[-1550,1550]:B.rect(*p(9250,cy-900),2900/50,1800/50,RED,None,.5,[2,1])
B.text(35,159,'Red dashed rectangles: earlier 2,900 x 1,800 removal-cover reservations; NOT existing deck openings.',2.7,True,RED)
# Actual ladder slope, no invented hatch above it.
B.text(35,145,'Port ladder / actual rise and run',3.4,True,TEAL)
ox,oy=40,68
B.line((ox,oy),(ox+1600/30,oy+70),TEAL,1.1);B.line((ox-8,oy),(ox+64,oy),GRAY,.2);B.line((ox-8,oy+70),(ox+64,oy+70),GRAY,.2)
B.dimh((ox,oy),(ox+1600/30,oy),oy-8,'1,600 run');B.dimv((ox+1600/30,oy),(ox+1600/30,oy+70),ox+63,'2,100 rise')
B.text(154,120,'52.7 deg nominal inclination',3,True);B.wrap(154,112,'750 mm ladder width. This is a geometric screen only; hands, hatch, head clearance and protected route are unresolved.',130,2.8,5)
y=365
for n,t,b in [('01','Escape route continuity','Trace both exits from the lowest occupied level to an unobstructed safe deck, including closed-door states. Current aft S ladder has 400 mm rung span, but no complete protected trunk is established.'),('02','Control booth and workshops','The present booth has one doorway back into the machinery space. Review an independent sheltered way out; do not count a view through glazing, an oil store or a locked room as an exit.'),('03','Human reference, correctly used','ClassNK Part R Chapter 13 is a design-check reference, not an asserted rule approval for this fictional 1994 domestic ferry. It distinguishes ladders from 800 x 800 clear vertical shelter envelopes and 600 mm horizontal shelters.'),('04','Engine removal','The prior 3.6 t machinery allowance plus 0.4 t rigging is a planning 4.0 t lift only. No beam, padeye, hook-height, open-deck crane path or through-car-deck closure has been proved.'),('05','Do not cut the car deck yet','Reserve removal openings only after coordinating vehicle loading, deck girders, watertight/weather closures, hatch handling, shore crane reach and lift stability.')]:y=B.note(322,y,n,t,b,245)

# 09 - accepted services only.
B.sheet('JS127-ER-C09','Services coordination / geometry-screened routes and open connections','1:50 @ A2')
p=plan(8500,22500,(32,173),50,False)
for pipe in I['engineeringPipes']:
    pts=[point(v)for v in pipe['points']]
    for a,b in zip(pts,pts[1:]):B.line(p(a[0],a[1]),p(b[0],b[1]),pipe['colour'],.3)
B.text(32,157,'Only the 55 current geometry-screened routes are shown. Their nozzle definitions and fabrication design remain unverified.',2.8,True,RED)
B.text(32,135,'Service',3,True);B.text(110,135,'Graph lines',3,True);B.text(163,135,'Screened',3,True);B.text(212,135,'Open physical',3,True)
counts=collections.Counter(i['system']for i in I['pipeRouteIssues']);clears=collections.Counter(i['system']for i in I['engineeringPipes'])
y=126
for sys in S['piping']:
    B.line((31,y-3),(300,y-3),'#d9e3df',.12);B.text(32,y,sys['name'],2.7);B.text(122,y,str(len(sys['lines'])),2.7);B.text(173,y,str(clears[sys['id']]),2.7);B.text(226,y,str(counts[sys['id']]),2.7);y-=6.4
y=365
for n,t,b in [('01','Current main baseline','206 positive-bore physical connections: 55 geometry-screened and 151 unresolved. Four further graph edges are signals. The 172 coloured game preview paths are excluded from the engineering-route overlay.'),('02','Fuel C1 already exists','PR #192, head 9761f61304d3, is OPEN and unmerged. It proposes distinct fuel interfaces and reports 67 screened / 139 unresolved whole-vessel connections. Those are candidate results, not current main.'),('03','Fuel head contradiction','Current main still states 1.8 m gravity head. Model service outlet Z=2,200, engine feed Z=2,050: only 150 mm interface elevation difference, not tank operating head. C1 already removes the unsupported assertion.'),('04','Route every function','For each pipe: identify origin, destination, bore/class, flow direction, valves, drains/vents, supports and bulkhead sleeve. Preserve maintenance and escape envelopes; a coloured line alone is insufficient.'),('05','Ventilation / exhaust / fire','Prove combustion and heat-rejection airflow with ducts and dampers; thermally separate exhaust from oil systems; define protected volumes and extinguishing boundaries before sizing or adding detail.')]:y=B.note(327,y,n,t,b,240)

# 10 - disposition, review gates and primary references.
B.sheet('JS127-ER-C10','Realism disposition / required corrections before modelling','NTS')
B.text(27,363,'Disposition: measured baseline complete; physical design remains open',4,True,RED)
B.wrap(27,352,'The drawing set preserves the current ferry. It is a concrete basis for correction, not evidence that the existing engine room is already fully realistic. The following gates must close before new equipment, demolition or a replacement interior is commissioned.',540,3.2,5.5)
rows=[
('R01','Headroom and overhaul','1,900 nominal; 250 above M1 envelope.','Choose viable maintenance/lifting method, including cover and hook travel.'),
('R02','Access around engines','Closed rail loops; side/booth interactions.','Design service gates and verify personnel / largest-part envelopes.'),
('R03','Escape and enclosure','One booth door; incomplete escape trunks.','Draw continuous, separated exits and fire boundaries through to safe deck.'),
('R04','Equipment identity','Fictional engine and machinery outlines.','Keep fictional branding; fix one coherent period-credible installation basis.'),
('R05','Pipes and interfaces','151 main connections unresolved.','Review existing fuel C1; coordinate other services with real valve/nozzle space.'),
('R06','Foundations and deck loads','No complete beams, mounts or lift structure.','Engineer supporting steel and shaft reactions before any deck opening.'),
('R07','Tanks / bilges / flooding','Shared reservations; individual partitions open.','Define boundaries, suctions, vents, access, tank calibration and bilge wells.'),
('R08','Air / heat / fire','Fan flat unbuilt; room boundaries incomplete.','Coordinate ventilation, cooling, exhaust lagging and suppression coverage.'),
('R09','Power and control','Electrical ratings are preliminary.','Verify motor starts, protection, cable routes and black-out / emergency supply.'),
('R10','Whole-vessel fit','Hull / weight assumptions unreconciled.','Check hull, stability and subdivision before changing floor or compartment size.'),
]
cols=[27,48,158,345];widths=[21,110,187,218];y=323
for x,w,t in zip(cols,widths,['ID','Review item','Existing evidence','Correction / acceptance gate']):B.rect(x,y-9,w,12,TEAL,LIGHT);B.text(x+2,y-5,t,2.9,True)
y-=9
for row in rows:
    for x,w,t in zip(cols,widths,row):B.rect(x,y-15,w,15,GRAY,None,.15);B.wrap(x+2,y-5,t,w-4,2.65,4.2)
    y-=15
B.text(27,147,'Source and reference control',3.6,True,TEAL)
refs=[
'Model: nj22az/nj22az.github.io main '+COMMIT+'; source modules and data are frozen in this package.',
'Prior baseline: Minato Maru Engine Room CAD Rev B, 13 October 2026; retained unchanged as a separate reference.',
'Fuel candidate: https://github.com/nj22az/nj22az.github.io/pull/192 | 9761f61304d3ac7a66d9061b593d61fce706805c | unmerged.',
'Yanmar: https://www.yanmar.com/media/news/2020/05/22051608/6aym-wstwet.pdf | operating reference; later than the setting.',
'Yanmar legacy outline: https://www.yanmar.no/theme/yanmarportal/uploadedFiles/Marine/productDownloads/Commercial-datasheet/6148-Datasheet-6AYM-WST.pdf',
'ClassNK: https://www.classnk.or.jp/hp/pdf/rules/460_part_r_e_202606.pdf | Ch.13 / R13; retrieved PDF labels its issue December 2025.',
]
y=137
for ref in refs:y=B.wrap(27,y,ref,539,2.45,4.1)-2
B.wrap(27,77,'Release boundary: no game source, runtime, equipment, residents, hull or ship schedule changed. Current pipe counts were rerun from the source export. Historic Rev B and C1 test counts are not claimed as newly run tests.',538,2.8,4.7,True,RED)
B.finish()

# Editable, full-size CAD: actual vessel datums. No screenshot tracing.
d=ezdxf.new('R2010');d.units=4;ms=d.modelspace()
for name,col in [('EQUIPMENT',3),('STRUCTURE',8),('RAILS',2),('PIPES_SCREENED',4),('DIMENSIONS',7),('TEXT',7),('RESERVATION',1)]:d.layers.new(name,dxfattribs={'color':col})
for b in BOX:
    lo,hi=b['lo'],b['hi'];name=b.get('name')or''
    if lo[0]<6900 or hi[0]>26060 or hi[2]>2800:continue
    if not b.get('name')or any(k in name for k in['deckhead','floor plates']):continue
    layer='RAILS'if'rail'in name else'STRUCTURE'if any(k in name for k in['bulkhead','partition','side','trunk'])else'EQUIPMENT'
    ms.add_lwpolyline([(lo[0],lo[1]),(hi[0],lo[1]),(hi[0],hi[1]),(lo[0],hi[1])],close=True,dxfattribs={'layer':layer})
for c in CYL:
    from scipy.spatial import ConvexHull
    v=c['vertices'][:,[0,1]]
    try:v=v[ConvexHull(v).vertices]
    except Exception:continue
    ms.add_lwpolyline(v.tolist(),close=True,dxfattribs={'layer':'EQUIPMENT'})
for pipe in I['engineeringPipes']:
    pts=[point(p)for p in pipe['points']];ms.add_lwpolyline([(p[0],p[1])for p in pts],dxfattribs={'layer':'PIPES_SCREENED'})
def dim(p1,p2,base,angle=0):
    a=ms.add_linear_dim(base=base,p1=p1,p2=p2,angle=angle,override={'dimtxt':125,'dimasz':100,'dimgap':40,'dimexo':50,'dimexe':100,'dimdec':0},dxfattribs={'layer':'DIMENSIONS'});a.render()
dim((8500,3980),(14000,3980),(8500,4850));dim((14000,3980),(19000,3980),(14000,4850));dim((19000,3980),(22500,3980),(19000,4850));dim((22500,3980),(26000,3980),(22500,4850))
dim((8500,-3980),(8500,3980),(7750,-3980),90);dim((11000,-630),(11000,630),(11200,-630),90);dim((11000,-1550),(11000,1550),(12500,-1550),90)
for x,t in[(10000,'MAIN ENGINE ROOM'),(15000,'AUXILIARY MACHINERY'),(19300,'MECHANICAL / STORE'),(22800,'ELECTRICAL WORKSHOP')]:ms.add_text(t,dxfattribs={'height':140,'layer':'TEXT'}).set_placement((x,5400))
ms.add_text('REV C | CURRENT MODEL | CAD mm X FWD FROM TRANSOM, Y PORT | NO GAME CHANGE',dxfattribs={'height':130,'layer':'TEXT'}).set_placement((7200,-5500))
layout=d.layouts.new('A2_PLAN_1_50');layout.page_setup(size=(594,420),margins=(10,10,10,10),units='mm')
vp=layout.add_viewport(center=(287,200),size=(548,310),view_center_point=(16600,0),view_height=15500);vp.dxf.flags|=16384
d.saveas(OUT/'cad/Minato_Maru_Machinery_Plan_1to1_mm.dxf')

# Longitudinal section CAD, absolute X / Z projections in its own model space.
d=ezdxf.new('R2010');d.units=4;ms=d.modelspace()
for b in BOX:
    lo,hi=b['lo'],b['hi']
    if lo[0]<8500 or hi[0]>26060 or hi[2]>2980 or not(lo[1]<=1550<=hi[1]):continue
    ms.add_lwpolyline([(lo[0],lo[2]),(hi[0],lo[2]),(hi[0],hi[2]),(lo[0],hi[2])],close=True)
for z in[700,900,2800,3000]:ms.add_line((8500,z),(26000,z))
for x in[8500,14000,19000,22500,26000]:ms.add_line((x,900),(x,2800))
v=ms.add_linear_dim(base=(27000,900),p1=(26000,900),p2=(26000,2800),angle=90,override={'dimtxt':100,'dimasz':80,'dimdec':0});v.render()
ms.add_text('REV C | PORT SECTION Y=1550 | X FWD FROM TRANSOM / Z ABOVE BASELINE | CAD mm',dxfattribs={'height':130}).set_placement((8500,3500))
d.saveas(OUT/'cad/Minato_Maru_Port_Section_1to1_mm.dxf')

# Complete machine-readable survey and provenance.
inventory=[]
for b in BOX:
    if b.get('name'):
        inventory.append(dict(id='BOX-'+str(b['index']),name=b['name'],Xmin_mm=round(b['lo'][0],3),Xmax_mm=round(b['hi'][0],3),Ymin_mm=round(b['lo'][1],3),Ymax_mm=round(b['hi'][1],3),Zmin_mm=round(b['lo'][2],3),Zmax_mm=round(b['hi'][2],3),drawn=b.get('draw')is not False,solid=b.get('solid'),basis='Current source envelope; not supplier fabrication geometry'))
csvout(OUT/'data/equipment_and_structure_survey.csv',inventory)
csvout(OUT/'data/pipe_route_issues_current_main.csv',I['pipeRouteIssues'])
csvout(OUT/'data/pipe_connections.csv',[dict(system=sys['id'],line_index=k,from_node=l['from'],to_node=l['to'],DN=l['dn'],note=l.get('note',''))for sys in S['piping']for k,l in enumerate(sys['lines'])])
(OUT/'data/current_main_snapshot.json').write_text(json.dumps(S,indent=2))
(OUT/'data/accepted_route_screen.json').write_text(json.dumps(I['engineeringPipes'],indent=2))
(OUT/'data/realism_gates.json').write_text(json.dumps([dict(id=r[0],item=r[1],evidence=r[2],gate=r[3])for r in rows],indent=2))
for path in (ROOT/'cache/johansson-town/src/world').glob('*.js'):shutil.copy2(path,OUT/'source'/path.name)
shutil.copy2(ROOT/'build_engine_room.py',OUT/'source/build_engine_room.py')
shutil.copy2(ROOT/'tmp/equipment_bars.json',OUT/'data/equipment_bars.json')
shutil.copy2(ROOT/'reference/Minato_Maru_Engine_Room_CAD_Reviewed_RevB.zip',OUT/'references/Original_RevB_Unchanged.zip')
provenance=dict(main_commit=COMMIT,date=DATE,scope='drawings and audit only; repository unchanged',fuel_C1=dict(pr=192,state='OPEN / UNMERGED',head='9761f61304d3ac7a66d9061b593d61fce706805c',reported_not_rerun=dict(clear=67,unresolved=139)),source_current=dict(accepted_geometry_routes=55,unresolved_positive_bore=151,illustrative_preview_routes_excluded=172),cutaway_meshes=mesh_count,coordinates='CAD mm: X forward from transom, Y port, Z above baseline',source_hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in(OUT/'source').glob('*.js')})
(OUT/'data/provenance.json').write_text(json.dumps(provenance,indent=2))
readme='''# Minato Maru - engine room CAD and realism review, Rev C\n\n31 October 2026. Drawings and survey only. No game or repository changes.\n\nOpen the ten-sheet A2 PDF first. Plans, source-derived cutaway, longitudinal and transverse sections, engine detail, access/removal review, current pipe disposition and the correction gates all use the current main model. The upper-floor electrical workshop, absent from the old source snapshot, is included; it is below the car deck, not a second machinery storey.\n\nCAD uses millimetres: X forward from transom; Y to port; Z up from baseline. The master plan uses actual X/Y coordinates and native dimension entities; the separate longitudinal section uses actual X/Z. The 3D OBJ and DXF are source polygon references, not STEP solids, manufacturer installation drawings or fabrication models. The cutaway omits external walls/deckheads only for viewing. Hidden collision envelopes are scheduled; they are not rendered as real machines. No cartoon scaling was used to clear a conflict.\n\nSOLID COLOUR = current source. RED DASHED = retained preliminary reservation / review issue, not an approved new fitting. 1:25, 1:40 and 1:50 drawings print at their stated A2 scale. Do not scale a preview or a screen image; dimensions govern.\n\nCurrent main: f49f22ba82e6d4b1fd9b5033f8bddc4d3eed903f. Export rerun from source. The package retains original Rev B unchanged in references. C1 fuel PR #192 remains open and unmerged; its reported 67/139 route counts are not substituted for main's rerun 55/151. Main's 172 illustrative pipe previews are excluded from the engineering overlay. This issue does not supersede C1, select an engine, approve piping, certify escape, or authorise equipment additions/removals.\n\nThe engine room is not yet 100% physically realistic. Close R01-R10 before replacing the game interior: access and closed rail loops, headroom/overhaul, protected escape, coherent engine/gear installation, separate pipe interfaces, structural foundations, tanks and bilges, ventilation/exhaust/fire, electrical protection and whole-vessel loading/subdivision. The physical limits are specifically dimensioned rather than hidden.\n\nVerification: see data/validation.json after final render and CAD review. No gameplay, physical-device, onboard, OEM or statutory approval is claimed. Source snapshots and the drawing generator are supplied for reproducibility. For regeneration, retain the package-relative data/current_main_snapshot.json and data/equipment_bars.json and adapt the input/output paths at the top of source/build_engine_room.py; it is a snapshot generator, not an in-game builder.\n'''
(OUT/'README.txt').write_text(readme)
print(json.dumps({'output':str(OUT),'pages':len(B.pages),'boxes':len(BOX),'named_survey_entries':len(inventory),'cylinders':len(CYL),'cutaway_meshes':mesh_count}))
