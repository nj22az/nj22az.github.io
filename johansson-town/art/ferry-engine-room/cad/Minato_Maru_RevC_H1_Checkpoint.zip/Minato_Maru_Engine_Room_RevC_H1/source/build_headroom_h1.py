#!/usr/bin/env python3
"""Owner-directed headroom concept. Inventory, machinery floor and shaft axes retained."""
from pathlib import Path
import math,json,shutil,collections
import numpy as np
import ezdxf
from pypdf import PdfReader,PdfWriter

BASE=Path(__file__).resolve().parent
ns={'__file__':str(BASE/'build_engine_room.py'),'__name__':'headroom_helpers'}
exec((BASE/'build_engine_room.py').read_text().split('B=Book()')[0],ns)
globals().update({k:v for k,v in ns.items() if not k.startswith('__')})
BASEOUT=OUT
OUT=BASEOUT/'headroom_H1'
for f in ['drawings','data','cad','previews']:(OUT/f).mkdir(parents=True,exist_ok=True)
ns['OUT']=OUT
Book.__init__.__globals__['OUT']=OUT
B=Book(total=2,filename='Minato_Maru_Headroom_H1.pdf',proposal=True)
# Authorised change is a design drawing, not a runtime build.
FP=900;CLEAR=2400;SERVICE_BOTTOM=3300;DECKHEAD=3600;CAR=4000;PASS=8400
H1=dict(working_floor_mm=FP,minimum_clear_working_headroom_mm=CLEAR,services_keep_above_mm=SERVICE_BOTTOM,lowest_structural_underside_mm=DECKHEAD,nominal_room_height_mm=2700,overhead_services_reservation_mm=300,vehicle_deck_structure_reservation_mm=400,car_deck_mm=CAR,passenger_deck_mm=PASS,bridge_deck_mm=11000,compass_deck_mm=13400,upper_deck_increase_mm=1000,machinery_deckhead_increase_mm=800,ladder=dict(head_X_mm=6400,foot_X_mm=8600,rise_mm=3100,run_mm=2200,clear_width_mm=800,inclination_degrees=math.degrees(math.atan(3100/2200)),proposed_hatch_X_mm=[6400,9000],existing_hatch_width_mm=980),status='CAD PROPOSAL ONLY; structural and vessel-wide design still required')

def person(p,cy=0):
    # 1,800 mm standing human plus 80 mm helmet, not a scaled-down game avatar.
    def at(y,z):return p(cy+y,z)
    B.poly([at(-150,FP+1020),at(150,FP+1020),at(225,FP+1450),at(150,FP+1570),at(-150,FP+1570),at(-225,FP+1450)],TEAL,'#c7ded4',.45)
    B.line(at(-95,FP+1020),at(-150,FP+20),TEAL,.9);B.line(at(95,FP+1020),at(150,FP+20),TEAL,.9)
    B.line(at(-180,FP+1480),at(-270,FP+950),TEAL,.6);B.line(at(180,FP+1480),at(270,FP+950),TEAL,.6)
    B.circle(*at(0,FP+1700),100/20,TEAL,'#f1e5cc')
    B.rect(*at(-125,FP+1800),250/20,80/20,TEAL,'#e6cc71',.3)
    B.text(*at(0,FP-490),'1,800 mm person + 80 mm helmet',2.8,True,TEAL,align='center')

B.sheet('JS127-ER-H1-01','Enlarged engine-room headroom / owner-directed CAD proposal','1:20 @ A2')
B.text(30,363,'2,400 mm clear below services. Machinery stays at its present level.',5,True,TEAL)
B.wrap(30,352,'The room becomes 800 mm taller at the structural underside. A separate 400 mm vehicle-deck structural reservation makes the proposed car deck 1,000 mm higher. Raising the decks above by the same 1,000 mm retains the existing vehicle and accommodation clearances.',534,3.2,5.5)
ox,oy=35,113
def p(y,z):return(ox+(y+3980)/20,oy+z/20)
B.rect(*p(-3980,FP),7960/20,CLEAR/20,TEAL,'#edf5ef',.3)
B.rect(*p(-3980,SERVICE_BOTTOM),7960/20,300/20,GOLD,'#f2e8ca',.3)
for y in np.arange(-3900,3980,350):B.line(p(y,SERVICE_BOTTOM),p(y+250,DECKHEAD),GOLD,.15)
B.rect(*p(-3980,DECKHEAD),7960/20,400/20,INK,'#c8d1cc',.4)
for z in[2800,3000]:B.line(p(-3980,z),p(3980,z),RED,.3,[3,1.5])
B.text(*p(-3900,2835),'OLD DECKHEAD +2,800',2.6,True,RED)
B.text(*p(-3900,3035),'OLD CAR DECK +3,000',2.6,True,RED)
B.rect(*p(-3980,840),7960/20,60/20,INK,'#889d94',.4)
B.line(p(-3980,700),p(3980,700),GRAY,.25,[3,1])
for b in BOX:
    lo,hi=b['lo'],b['hi']
    if not(lo[0]<=10700<=hi[0])or hi[2]>2800 or hi[2]<900 or b.get('draw')is False:continue
    B.rect(*p(lo[1],lo[2]),(hi[1]-lo[1])/20,(hi[2]-lo[2])/20,INK,colour(b['hex']),.22)
for cy in[-1550,1550]:B.rect(*p(cy-750,900),1500/20,1650/20,RED,None,.4,[2,1])
person(p)
B.dimv(p(3980,FP),p(3980,SERVICE_BOTTOM),449,'2,400 CLEAR')
B.dimv(p(-3980,FP),p(-3980,DECKHEAD),23,'2,700 nominal')
B.dimh(p(-3980,FP),p(3980,FP),143,'7,960 current internal breadth')
B.text(35,315,'PROPOSED CAR DECK +4,000',3.1,True,TEAL)
B.text(35,295,'STRUCTURAL UNDERSIDE +3,600',2.8,True,TEAL)
B.text(300,280,'SERVICES KEEP ABOVE +3,300',2.7,True,GOLD)
B.text(35,151,'WORKING FLOOR +900 / UNCHANGED',2.9,True,TEAL)
B.text(35,139,'TANK TOP +700 / UNCHANGED',2.6,col=GRAY)
B.wrap(492,307,'No ducking in designated standing and working areas. Pipes, trays, valves, handles and insulation must stay outside the clear-height envelope.',78,3.2,5.5,bold=True,col=TEAL)
B.wrap(492,244,'Engine and gear centres, foundations, tanks and machinery count remain fixed in this concept. Engine top/removal envelopes still require actual supplier data.',78,2.9,5.1)
B.wrap(492,183,'400 mm is a structural planning reservation, not a calculated beam size. If selected structure or services need more depth, increase deck elevations; do not consume the 2,400 mm clear space.',78,2.9,5.1,col=RED)
B.text(30,112,'What this changes',3.5,True,TEAL)
B.wrap(30,102,'A uniform raised vehicle deck is used to avoid a local machinery hump in the car lanes. Passenger and bridge decks, casings, access, exhausts, vents, ramp hinge/landing arrangements, gangway landings and vertical services need to follow the new levels. Hull breadth, machinery floor and shaft lines are retained as design constraints.',536,3.0,5.2)
B.wrap(30,76,'This is the headroom design direction, subject to hull/structure/stability and access coordination. It does not approve a real-vessel conversion. The following ten survey sheets show the existing 1,900 mm baseline for comparison; H1 controls the proposed vertical dimensions.',536,2.8,4.8,True,RED)

# Page 2 makes the vessel-wide and ladder consequences reviewable.
B.sheet('JS127-ER-H1-02','Deck-height coordination / new ladder and protected working space','1:50 section / schedule NTS')
ox,oy=33,158
def l(x,z):return(ox+(x-6000)/50,oy+z/50)
B.text(33,365,'Longitudinal coordination / existing machinery remains in place',3.6,True,TEAL)
for z,name,col in[(900,'MACHINERY FLOOR +900',TEAL),(3300,'LOWEST SERVICES +3,300',GOLD),(3600,'STRUCTURAL UNDERSIDE +3,600',TEAL),(4000,'CAR DECK +4,000',TEAL),(8200,'VEHICLE CLEAR UNDERSIDE +8,200',TEAL),(8400,'PASSENGER DECK +8,400',TEAL)]:
    B.line(l(6000,z),l(26000,z),col,.38);B.text(*l(6000,z+60),name,2.6,True,col)
for z in[2800,3000,7400]:B.line(l(6000,z),l(26000,z),RED,.2,[3,1])
for x in[8500,14000,19000,22500,26000]:B.line(l(x,900),l(x,3600),GRAY,.3)
for x,t in[(9000,'MAIN ENGINES'),(15000,'AUXILIARIES'),(19500,'MECH / STORE'),(23000,'ELECTRICAL')]:B.text(*l(x,600),t,2.6,True,TEAL)
for b in BOX:
    lo,hi=b['lo'],b['hi']
    if not(lo[1]<=1550<=hi[1])or lo[0]<8500 or hi[0]>26000 or hi[2]>2800 or b.get('draw')is False:continue
    B.rect(*l(lo[0],lo[2]),(hi[0]-lo[0])/50,(hi[2]-lo[2])/50,INK,colour(b['hex']),.18)
# Proposed floor-level ladder: head moves 600 mm aft, foot retained.
B.line(l(6400,4000),l(8600,900),TEAL,1.1)
for t in np.linspace(0,1,13):
    x=6400+t*2200;z=4000-t*3100;B.line(l(x-90,z),l(x+90,z),TEAL,.3)
B.dimh(l(6400,900),l(8600,900),164,'2,200 run')
B.dimv(l(8600,900),l(8600,4000),88,'3,100 rise')
B.dimv(l(26000,4000),l(26000,8200),444,'4,200 vehicle clearance')
B.text(33,144,'Proposed port ladder: 800 mm clear; 54.6 deg nominal; head X=6,400, foot X=8,600.',2.9,True,TEAL)
B.text(33,135,'Hatch reservation X=6,400-9,000; retained nominal width 980. Landings, rails, treads and hull clearance require detail.',2.7,col=RED)
cols=[33,129,179,229];width=[96,50,50,212];y=120
for x,w,t in zip(cols,width,['Datum / function','Existing','H1 proposed','Coordination requirement']):B.rect(x,y-8,w,11,TEAL,LIGHT);B.text(x+2,y-4,t,2.7,True)
table=[('Tank top / floor','700 / 900','700 / 900','Retained; no tank or shaft-line lowering.'),('ER structural underside','2,800','3,600','800 mm gain; keep all services above 3,300 in work areas.'),('Car / passenger deck','3,000 / 7,400','4,000 / 8,400','Both +1,000; retain 4,200 vehicle clear height.'),('Bridge / compass deck','10,000 / 12,400','11,000 / 13,400','Raise upper geometry and services consistently.'),('Main access ladder','2,100 rise','3,100 rise','Extend run 1,600 to 2,200; no steeper shortcut.')]
y-=8
for row in table:
    for x,w,t in zip(cols,width,row):B.rect(x,y-11,w,11,GRAY,None,.15);B.wrap(x+2,y-4,t,w-4,2.55,4)
    y-=11
y=365
for n,t,b in [('01','Vertical design decision','Raise car deck and upper decks by 1,000; raise lowest machinery deck structure by 800. The extra 200 increases the former 200 mm deck envelope to a 400 mm reservation.'),('02','No silent loss of capacity','Preserve vehicle clear height. Revised overall height, freeboard, lightship/KG, windage, ramp slope, berthing and structure require verification before any game build.'),('03','Ladder follows deck','A 3,100 rise with the old 1,600 run would be 62.7 deg. The 2,200 run gives 54.6 deg. A longer flight and landing must be modelled, not a stretched steep ladder.'),('04','Fire and ventilation','New machinery volume affects fire suppression and ventilation. Recalculate protected volumes, fan duties and exhaust support. Do not reuse the old 190 m3 CO2 basis.'),('05','Pipe routing is reopened','Baseline accepted paths are not accepted against H1 headroom. Move route design to the new overhead zone and recheck ownership, valves, supports, penetrations and escape.')]:y=B.note(483,y,n,t,b,88)
B.finish()

# 1:1 native dimensioned H1 cross-section. Actual Y / Z vessel datums.
d=ezdxf.new('R2010');d.units=4;ms=d.modelspace()
for name,c in [('EXISTING',1),('H1_STRUCTURE',3),('H1_CLEAR_SPACE',4),('H1_SERVICE_ZONE',2),('EQUIPMENT_RETAINED',7),('DIMENSIONS',7)]:d.layers.new(name,dxfattribs={'color':c})
def cadrect(a,b,layer):ms.add_lwpolyline([a,(b[0],a[1]),b,(a[0],b[1])],close=True,dxfattribs={'layer':layer})
cadrect((-3980,900),(3980,3300),'H1_CLEAR_SPACE');cadrect((-3980,3300),(3980,3600),'H1_SERVICE_ZONE');cadrect((-3980,3600),(3980,4000),'H1_STRUCTURE')
for z in[700,900,2800,3000]:ms.add_line((-3980,z),(3980,z),dxfattribs={'layer':'EXISTING'})
for b in BOX:
    lo,hi=b['lo'],b['hi']
    if lo[0]<=10700<=hi[0] and hi[2]<=2800 and b.get('draw')is not False:cadrect((lo[1],lo[2]),(hi[1],hi[2]),'EQUIPMENT_RETAINED')
def dim(a,b,base,angle=90):
    e=ms.add_linear_dim(base=base,p1=a,p2=b,angle=angle,override={'dimtxt':65,'dimasz':55,'dimdec':0},dxfattribs={'layer':'DIMENSIONS'});e.render()
dim((3980,900),(3980,3300),(4500,900));dim((-3980,900),(-3980,3600),(-4600,900));dim((-3980,900),(3980,900),(-3980,250),0)
ms.add_text('H1 PROPOSAL | Y PORT / Z ABOVE BASELINE | CAD mm | NO GAME CHANGE',dxfattribs={'height':100}).set_placement((-3980,4550))
layout=d.layouts.new('A2_SECTION_1_20');layout.page_setup(size=(594,420),margins=(10,10,10,10),units='mm')
vp=layout.add_viewport(center=(287,200),size=(548,310),view_center_point=(0,2300),view_height=6200);vp.dxf.flags|=16384
d.saveas(OUT/'cad/Minato_Maru_H1_Transverse_1to1_mm.dxf')
d=ezdxf.new('R2010');d.units=4;ms=d.modelspace()
for z in[900,3300,3600,4000,8200,8400]:ms.add_line((6000,z),(26000,z))
ms.add_line((6400,4000),(8600,900))
for x in[8500,14000,19000,22500,26000]:ms.add_line((x,900),(x,3600))
for b in BOX:
    lo,hi=b['lo'],b['hi']
    if not(lo[1]<=1550<=hi[1])or lo[0]<8500 or hi[0]>26000 or hi[2]>2800 or b.get('draw')is False:continue
    ms.add_lwpolyline([(lo[0],lo[2]),(hi[0],lo[2]),(hi[0],hi[2]),(lo[0],hi[2])],close=True)
for a,b,base,ang in [((8600,900),(8600,4000),(9000,900),90),((6400,900),(8600,900),(6400,500),0),((26000,4000),(26000,8200),(27000,4000),90)]:
    e=ms.add_linear_dim(base=base,p1=a,p2=b,angle=ang,override={'dimtxt':100,'dimasz':90,'dimdec':0});e.render()
ms.add_text('H1 PROPOSAL | X FROM TRANSOM / Z ABOVE BASELINE | CAD mm | NO GAME CHANGE',dxfattribs={'height':120}).set_placement((6000,9000))
layout=d.layouts.new('A2_SECTION_1_50');layout.page_setup(size=(594,420),margins=(10,10,10,10),units='mm')
vp=layout.add_viewport(center=(287,200),size=(548,310),view_center_point=(16000,4500),view_height=15500);vp.dxf.flags|=16384
d.saveas(OUT/'cad/Minato_Maru_H1_Longitudinal_1to1_mm.dxf')

def intersect(a,b,lo,hi,r):
    # Segment against expanded AABB. Endpoints and finite pipe radius included.
    lo=np.array(lo)-r;hi=np.array(hi)+r;dv=b-a;t0,t1=0.,1.
    for k in range(3):
        if abs(dv[k])<1e-9:
            if a[k]<lo[k]or a[k]>hi[k]:return False
        else:
            aa,bb=sorted(((lo[k]-a[k])/dv[k],(hi[k]-a[k])/dv[k]));t0=max(t0,aa);t1=min(t1,bb)
            if t0>t1:return False
    return True
volumes=[('ER centre',[8600,-630,900],[14000,630,3300]),('Aux centre',[14000,-500,900],[19000,500,3300])]
intrusions=[]
for pipe in I['engineeringPipes']:
    pts=[point(v)for v in pipe['points']];r=max(.012,pipe['dn']*.0006+.004)*1000
    hits=[name for name,lo,hi in volumes if any(intersect(a,b,lo,hi,r)for a,b in zip(pts,pts[1:]))]
    if hits:intrusions.append(dict(lineId=pipe['lineId'],system=pipe['system'],DN=pipe['dn'],headroom_volumes=hits))
(OUT/'data/headroom_design.json').write_text(json.dumps(H1,indent=2))
(OUT/'data/legacy_routes_in_headroom.json').write_text(json.dumps(dict(scope='Screen of two centre-route volumes only; not complete overhead coordination',count=len(intrusions),routes=intrusions),indent=2))
writer=PdfWriter()
for f in [OUT/'Minato_Maru_Headroom_H1.pdf',BASEOUT/'Minato_Maru_Engine_Room_RevC.pdf']:
    for page in PdfReader(f).pages:writer.add_page(page)
writer.add_metadata({'/Title':'Minato Maru - Enlarged Engine Room CAD - Rev C / Headroom H1','/Author':'Johansson World - engineering arrangement study'})
with open(BASEOUT/'Minato_Maru_Engine_Room_RevC_H1.pdf','wb')as f:writer.write(f)
shutil.copy2(BASE/'build_headroom_h1.py',BASEOUT/'source/build_headroom_h1.py')
print(json.dumps({'headroom':H1,'legacy_screened_routes_intruding_two_centre_volumes':len(intrusions),'combined_pages':len(writer.pages)}))
