# Minato Maru engine room - CAD Rev C / H1 handover

31 October 2026. CAD checkpoint, before runtime implementation.

## Owner instructions

Draw/CAD the existing ferry before adding/removing machinery; require physical realism despite cartoon styling. Then enlarge headroom for comfortable work. Latest instruction: build in Blender and Meshy, apply to World, use locked camera angles so the engine room remains explorable and attractive.

## Verified baseline

Repo nj22az/nj22az.github.io main f49f22ba82e6d4b1fd9b5033f8bddc4d3eed903f. Current source exported locally: 1,245 boxes, 896 bars, 918 cylinders; 55 screened engineering paths and 151 open positive-bore connections. 432 preview-only bars were identified exactly and excluded from the equipment-bar export. Rev B retained unchanged. Fuel C1 PR #192, head 9761f61304d3ac7a66d9061b593d61fce706805c, is open and unmerged; its 67/139 counts are historical candidate evidence, not rerun main results. Current electrical workshop included.

## CAD delivered

Twelve A2 sheets: first two H1 proposed height/ladder coordination, followed by ten current-model survey sheets. Five editable DXFs use 1:1 mm and native dimensions; OBJ/source data and sheet SVGs included. See data/validation.json. H1 PDF's 2,400 dimension measures 120 mm at 1:20. All DXFs reopened with units=4, zero errors/fixes. Sheets visually reviewed.

## H1 controls the new vertical design

Floor +900 and tank top +700 retained. Clear standing/working space +900 to +3,300 = 2,400. Overhead service zone +3,300 to +3,600. Structural planning zone +3,600 to +4,000. New car deck +4,000; passenger +8,400; bridge +11,000; compass +13,400. Upper decks rise 1,000 mm; machinery underside rises 800 mm. Existing machinery positions/count/shaft axes retained. Proposed port ladder head X6,400 / foot X8,600; rise 3,100 / run 2,200 = 54.64 deg; clear width 800. Eight baseline screened routes intrude two sampled H1 centre-route volumes; reroute/revalidate.

## Implementation boundary

No runtime or repository changes made by the CAD checkpoint. No construction, flag/class, OEM, structure or stability approval. Raised decks affect hull/freeboard, lightship/KG, ramps, gangways, ventilation, exhaust, fire volumes, vertical services and access. These must be coordinated, not hidden by a taller interior disconnected from the ferry exterior. Baseline source mesh is a reference, not the final Blender scene.

Follow root AGENTS/CLAUDE and johansson-town/AGENTS. Use development for the detailed prototype. Main remains the published cartoon World; do not publish without the owner's word. Preserve newer work and saves. Record the eventual exact source branch/commit, Blender build/export, camera behaviour and verification in the repository handover. Meshy sign-in/API access is not yet available; do not claim generated assets.
