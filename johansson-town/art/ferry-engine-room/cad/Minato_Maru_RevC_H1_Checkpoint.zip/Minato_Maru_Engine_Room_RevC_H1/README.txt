# PRIMARY ISSUE: REV C / HEADROOM H1

Open Minato_Maru_Engine_Room_RevC_H1.pdf (12 A2 pages). The first TWO sheets are the new enlarged-headroom proposal. The following TEN sheets are the unchanged-position CURRENT-MODEL SURVEY used to coordinate that proposal. Do not build the old 1,900 mm height from the survey: H1 governs proposed vertical dimensions.

Owner direction: enlarge the headroom for comfortable work, while drawing/CAD precedes game changes. H1 reserves 2,400 mm clear below services, with a 2,700 mm nominal room height. Floor +900 is retained. Services stay above +3,300; structural underside +3,600; a 400 mm structure reservation puts car deck at +4,000. Passenger/bridge/compass decks become +8,400/+11,000/+13,400. All upper decks therefore rise 1,000 mm, while the machinery underside rises 800 mm. These are design reservations, not verified scantlings or an approved rebuilt ship.

The new ladder rises 3,100 over a 2,200 run (54.64 degrees), 800 mm clear. The old short run is not stretched. Foundations, shaft axes, machinery positions, tank-top and count are retained. No local hump is introduced into vehicle lanes; the 4,200 mm vehicle clearance is retained. Full hull, weight/KG/stability, structure, ramps/gangways, exhaust/vent and fire-volume coordination remains open. Eight of the existing 55 geometry-screened routes intrude two sampled H1 centre-aisle volumes; this is a new proposal conflict screen, not accepted new routing.

No game, repository or published site was changed. The handover is included for review; no repository handover pointer was committed during this CAD-only task.

Reproduce the drawings offline with installed Python reportlab, ezdxf, matplotlib, numpy, scipy, Pillow and pypdf:
  python source/reproduce_engine_room.py --out /absolute/path/to/new-empty-output
The frozen source snapshot is the input. Visual review, delivery packaging and final validation records are separate from this generator.

The following original Rev C notes apply to the ten baseline survey sheets and source mesh, not to H1 proposed heights:

# Minato Maru - engine room CAD and realism review, Rev C

31 October 2026. Drawings and survey only. No game or repository changes.

Open the ten-sheet A2 PDF first. Plans, source-derived cutaway, longitudinal and transverse sections, engine detail, access/removal review, current pipe disposition and the correction gates all use the current main model. The later electrical workshop, absent from the old source snapshot, is included; it is below the car deck, not a second machinery storey.

CAD uses millimetres: X forward from transom; Y to port; Z up from baseline. The master plan uses actual X/Y coordinates and native dimension entities; the separate longitudinal section uses actual X/Z. The 3D OBJ and DXF are source polygon references, not STEP solids, manufacturer installation drawings or fabrication models. The cutaway omits external walls/deckheads only for viewing. Hidden collision envelopes are scheduled; they are not rendered as real machines. No cartoon scaling was used to clear a conflict.

SOLID COLOUR = current source. RED DASHED = retained preliminary reservation / review issue, not an approved new fitting. 1:25, 1:40 and 1:50 drawings print at their stated A2 scale. Do not scale a preview or a screen image; dimensions govern.

Current main: f49f22ba82e6d4b1fd9b5033f8bddc4d3eed903f. Export rerun from source. The package retains original Rev B unchanged in references. C1 fuel PR #192 remains open and unmerged; its reported 67/139 route counts are not substituted for main's rerun 55/151. Main's 172 illustrative pipe previews are excluded from the engineering overlay. This issue does not supersede C1, select an engine, approve piping, certify escape, or authorise equipment additions/removals.

The engine room is not yet 100% physically realistic. Close R01-R10 before replacing the game interior: access and closed rail loops, headroom/overhaul, protected escape, coherent engine/gear installation, separate pipe interfaces, structural foundations, tanks and bilges, ventilation/exhaust/fire, electrical protection and whole-vessel loading/subdivision. The physical limits are specifically dimensioned rather than hidden.

Verification: see data/validation.json after final render and CAD review. No gameplay, physical-device, onboard, OEM or statutory approval is claimed. Source snapshots and the drawing generator are supplied for reproducibility. For regeneration, retain the package-relative data/current_main_snapshot.json and data/equipment_bars.json and adapt the input/output paths at the top of source/build_engine_room.py; it is a snapshot generator, not an in-game builder.
