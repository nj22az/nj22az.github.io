# Drinking simulator — portable source

Beer, whiskey and gin and tonic share one sober 6.6-second drinking animation.
This archive contains the standalone lab and its actual editable Blender model.
The full Johansson World integration and browser evidence are in the repository.

## Run

Extract the archive and, from this folder, run:

```sh
python3 -m http.server 5175 --bind 127.0.0.1
```

Open http://127.0.0.1:5175/drinking-simulator/ in a WebGL2 browser.
All runtime dependencies are included (Three.js r170); no install or CDN is needed.
Use Take a sip or Space. Inspect reveals pause, slow motion, cameras and markers.

## Tests

With Node 24 or newer, run `npm test`. No npm installation is required for these
focused tests. The complete repository has additional game, runtime and browser tests.

## Edit

- `src/drinking/`: shared clock, constraints, rig, hand, profiles, vessel and liquid.
- `drinking-simulator/`: browser presentation and controls.
- `assets/models/drinking/drinking-mannequin.blend`: editable model.
- `tools/blender/build-drinking-mannequin.py`: reproducible Blender authoring source.
- `docs/DRINKING-SIMULATOR.md`: architecture, event API, measured checks and limits.
- `vendor/LICENSE-THREE.txt`: Three.js dependency licence.

The repository production-build commands in the detailed document apply to the
full Johansson World checkout. This portable lab runs directly from the server above.
